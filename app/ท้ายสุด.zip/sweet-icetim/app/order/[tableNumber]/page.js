'use client';

import { use, useEffect, useRef, useState } from 'react';
import { supabase } from '../../../lib/supabaseClient';

const ADULT_PRICE = 289;
const CHILD_PRICE = 145;
const MAX_QTY = 5; // จำนวนต่อรายการ 1-5
const MAX_LINES = 10; // จำนวนรายการต่อการส่ง 1 ครั้ง
const NOTICE_MS = 5000;

const baht = (n) => n.toLocaleString('th-TH');

function Stepper({ name, qty, onDec, onInc, canInc }) {
  return (
    <div className="o-stepper">
      <button type="button" onClick={onDec} aria-label={`ลด ${name}`}>
        −
      </button>
      <span>{qty}</span>
      <button
        type="button"
        onClick={onInc}
        disabled={!canInc}
        aria-label={`เพิ่ม ${name}`}
      >
        +
      </button>
    </div>
  );
}

export default function OrderPage({ params }) {
  // params เป็น Promise ใน Next.js เวอร์ชันล่าสุด ต้อง unwrap ด้วย use() ก่อนใช้งาน
  const { tableNumber } = use(params);
  const table = Number(tableNumber);
  const validTable = /^\d+$/.test(tableNumber) && table >= 1;

  // loading | ready | no-session | error | closed
  const [phase, setPhase] = useState(validTable ? 'loading' : 'no-session');
  const [session, setSession] = useState(null);
  const [categories, setCategories] = useState([]);
  const [items, setItems] = useState([]);
  const [activeCatId, setActiveCatId] = useState(null);

  const [cart, setCart] = useState([]); // [{ id, name, quantity }]
  const [cartOpen, setCartOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [notice, setNotice] = useState(null); // { kind: 'ok' | 'err', text }

  const [showBill, setShowBill] = useState(false);
  const [closing, setClosing] = useState(false);
  const [billError, setBillError] = useState('');
  const cancelRef = useRef(null);

  // โหลด session ที่เปิดอยู่ แล้วค่อยโหลดเมนู
  useEffect(() => {
    if (!validTable) return;
    let cancelled = false;

    async function load() {
      try {
        const { data: rows, error: sessionError } = await supabase
          .from('sessions')
          .select('id, adult_count, child_count')
          .eq('table_number', table)
          .eq('status', 'open')
          .order('created_at', { ascending: false })
          .limit(1);
        if (sessionError) throw sessionError;
        if (cancelled) return;

        const found = rows?.[0] ?? null;
        if (!found) {
          setPhase('no-session');
          return;
        }

        const [catRes, itemRes] = await Promise.all([
          supabase
            .from('menu_categories')
            .select('id, name, sort_order')
            .order('sort_order', { ascending: true }),
          supabase
            .from('menu_items')
            .select('id, category_id, name')
            .order('id', { ascending: true }),
        ]);
        if (catRes.error) throw catRes.error;
        if (itemRes.error) throw itemRes.error;
        if (cancelled) return;

        setSession(found);
        setCategories(catRes.data ?? []);
        setItems(itemRes.data ?? []);
        setPhase('ready');
      } catch (err) {
        console.error(err);
        if (!cancelled) setPhase('error');
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [table, validTable]);

  // ข้อความแจ้งเตือนหายเองหลังไม่กี่วินาที
  useEffect(() => {
    if (!notice) return;
    const t = setTimeout(() => setNotice(null), NOTICE_MS);
    return () => clearTimeout(t);
  }, [notice]);

  // หน้าต่างเรียกเก็บเงิน: Esc เพื่อปิด + โฟกัสที่ปุ่มยกเลิก
  useEffect(() => {
    if (!showBill) return;
    cancelRef.current?.focus();
    const onKey = (e) => {
      if (e.key === 'Escape' && !closing) setShowBill(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [showBill, closing]);

  // ---------- ตะกร้า ----------
  const cartFull = cart.length >= MAX_LINES;
  const qtyById = new Map(cart.map((l) => [l.id, l.quantity]));
  const showList = cartOpen && cart.length > 0;

  function addItem(item) {
    setCart((prev) => {
      const line = prev.find((l) => l.id === item.id);
      if (line) {
        if (line.quantity >= MAX_QTY) return prev;
        return prev.map((l) =>
          l.id === item.id ? { ...l, quantity: l.quantity + 1 } : l
        );
      }
      if (prev.length >= MAX_LINES) return prev;
      return [...prev, { id: item.id, name: item.name, quantity: 1 }];
    });
  }

  function removeItem(id) {
    setCart((prev) =>
      prev.flatMap((l) => {
        if (l.id !== id) return [l];
        return l.quantity <= 1 ? [] : [{ ...l, quantity: l.quantity - 1 }];
      })
    );
  }

  async function handleSubmit() {
    if (cart.length === 0 || submitting || !session) return;
    setSubmitting(true);
    setNotice(null);
    try {
      // เช็คอีกครั้งว่าโต๊ะยังเปิดอยู่ (พนักงานอาจปิดไปแล้ว)
      const { data: stillOpen, error: checkError } = await supabase
        .from('sessions')
        .select('id')
        .eq('id', session.id)
        .eq('status', 'open')
        .limit(1);
      if (checkError) throw checkError;
      if (!stillOpen || stillOpen.length === 0) {
        setPhase('no-session');
        return;
      }

      const { error: insertError } = await supabase.from('orders').insert({
        session_id: session.id,
        table_number: table,
        items: cart.map((l) => ({ name: l.name, quantity: l.quantity })),
        status: 'received',
      });
      if (insertError) throw insertError;

      setCart([]);
      setCartOpen(false);
      setNotice({ kind: 'ok', text: 'ส่งออเดอร์แล้ว' });
    } catch (err) {
      console.error(err);
      setNotice({ kind: 'err', text: 'ส่งออเดอร์ไม่สำเร็จ กรุณาลองใหม่อีกครั้ง' });
    } finally {
      setSubmitting(false);
    }
  }

  // ---------- เรียกเก็บเงิน ----------
  const adults = Number(session?.adult_count) || 0;
  const kids = Number(session?.child_count) || 0;
  const adultTotal = adults * ADULT_PRICE;
  const kidTotal = kids * CHILD_PRICE;
  const grandTotal = adultTotal + kidTotal;

  function openBill() {
    setBillError('');
    setShowBill(true);
  }

  async function handleConfirmBill() {
    if (!session) return;
    setClosing(true);
    setBillError('');
    try {
      // ปิดเฉพาะ session นี้ และเช็คซ้ำว่ายังเป็น 'open'
      const { error: updateError } = await supabase
        .from('sessions')
        .update({ status: 'closed' })
        .eq('id', session.id)
        .eq('status', 'open')
        .select('id');
      if (updateError) throw updateError;

      setShowBill(false);
      setCart([]);
      setPhase('closed');
    } catch (err) {
      console.error(err);
      setBillError('เรียกเก็บเงินไม่สำเร็จ กรุณาลองใหม่อีกครั้ง');
    } finally {
      setClosing(false);
    }
  }

  // ---------- แสดงผล ----------
  const currentCatId = activeCatId ?? categories[0]?.id ?? null;
  const currentCat = categories.find((c) => c.id === currentCatId);
  const currentItems = items.filter((it) => it.category_id === currentCatId);

  let body;

  if (phase === 'loading') {
    body = (
      <div className="o-full">
        <p>กำลังโหลดเมนู...</p>
      </div>
    );
  } else if (phase === 'no-session') {
    body = (
      <div className="o-full">
        <h1>โต๊ะนี้ยังไม่เปิดใช้งาน กรุณาแจ้งพนักงาน</h1>
      </div>
    );
  } else if (phase === 'error') {
    body = (
      <div className="o-full">
        <h1>โหลดข้อมูลไม่สำเร็จ</h1>
        <p>กรุณารีเฟรชหน้านี้ ถ้ายังไม่ได้ให้แจ้งพนักงาน</p>
      </div>
    );
  } else if (phase === 'closed') {
    body = (
      <div className="o-full">
        <h1>ขอบคุณที่ใช้บริการ</h1>
        <p>สวีทไอติม</p>
      </div>
    );
  } else {
    body = (
      <>
        <div className="o-sticky">
          <div className="o-inner">
            <div className="o-top">
              <div>
                <span className="o-shop">สวีทไอติม</span>
                <span className="o-table">โต๊ะ {table}</span>
              </div>
              <button
                type="button"
                className="o-bill-btn"
                onClick={openBill}
                aria-haspopup="dialog"
              >
                เรียกเก็บเงิน
              </button>
            </div>
            {categories.length > 0 && (
              <div className="o-tabs" role="tablist" aria-label="หมวดหมู่เมนู">
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    type="button"
                    role="tab"
                    className="o-tab"
                    aria-selected={cat.id === currentCatId}
                    onClick={() => setActiveCatId(cat.id)}
                  >
                    {cat.name}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        <main className="o-menu">
          {categories.length === 0 ? (
            <div className="o-card">
              <p className="o-empty">ยังไม่มีรายการอาหารในเมนู</p>
            </div>
          ) : (
            <div className="o-card" role="tabpanel">
              <h2>{currentCat?.name}</h2>
              {currentItems.length === 0 ? (
                <p className="o-empty">ยังไม่มีเมนูในหมวดนี้</p>
              ) : (
                <ul className="o-list">
                  {currentItems.map((it) => {
                    const qty = qtyById.get(it.id) ?? 0;
                    return (
                      <li
                        key={it.id}
                        className={qty > 0 ? 'o-item in-cart' : 'o-item'}
                      >
                        <span className="o-item-name">{it.name}</span>
                        {qty === 0 ? (
                          <button
                            type="button"
                            className="o-add"
                            onClick={() => addItem(it)}
                            disabled={cartFull}
                            aria-label={`เพิ่ม ${it.name}`}
                          >
                            +
                          </button>
                        ) : (
                          <Stepper
                            name={it.name}
                            qty={qty}
                            onDec={() => removeItem(it.id)}
                            onInc={() => addItem(it)}
                            canInc={qty < MAX_QTY}
                          />
                        )}
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          )}
        </main>

        <footer className="o-cart">
          {showList && (
            <ul className="o-cart-list">
              {cart.map((l) => (
                <li key={l.id}>
                  <span className="o-item-name">{l.name}</span>
                  <Stepper
                    name={l.name}
                    qty={l.quantity}
                    onDec={() => removeItem(l.id)}
                    onInc={() => addItem(l)}
                    canInc={l.quantity < MAX_QTY}
                  />
                </li>
              ))}
            </ul>
          )}
          {notice && (
            <p className={`o-notice ${notice.kind}`} role="status">
              {notice.text}
            </p>
          )}
          {cartFull && !notice && (
            <p className="o-hint">
              เลือกครบ {MAX_LINES} รายการแล้ว ส่งออเดอร์ก่อน แล้วสั่งรอบใหม่ได้เลย
            </p>
          )}
          <div className="o-cart-bar">
            <button
              type="button"
              className="o-cart-toggle"
              onClick={() => setCartOpen((v) => !v)}
              disabled={cart.length === 0}
              aria-expanded={showList}
            >
              <span>
                ตะกร้า {cart.length}/{MAX_LINES} รายการ
              </span>
              <svg
                width="16"
                height="16"
                viewBox="0 0 16 16"
                aria-hidden="true"
                style={{ transform: showList ? 'rotate(180deg)' : 'none' }}
              >
                <path
                  d="M3 10l5-5 5 5"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>
            <button
              type="button"
              className="o-send"
              onClick={handleSubmit}
              disabled={cart.length === 0 || submitting}
            >
              {submitting ? 'กำลังส่ง...' : 'ส่งออเดอร์'}
            </button>
          </div>
        </footer>

        {showBill && (
          <div
            className="o-backdrop"
            onClick={() => !closing && setShowBill(false)}
          >
            <div
              className="o-modal"
              role="dialog"
              aria-modal="true"
              aria-labelledby="bill-title"
              onClick={(e) => e.stopPropagation()}
            >
              <h2 id="bill-title">เรียกเก็บเงิน โต๊ะ {table}</h2>
              <ul className="o-bill">
                <li>
                  <span>
                    ผู้ใหญ่ {adults} คน × {baht(ADULT_PRICE)}
                  </span>
                  <span>{baht(adultTotal)} บาท</span>
                </li>
                <li>
                  <span>
                    เด็ก {kids} คน × {baht(CHILD_PRICE)}
                  </span>
                  <span>{baht(kidTotal)} บาท</span>
                </li>
              </ul>
              <div className="o-total">
                <span>ยอดที่ต้องจ่าย</span>
                <strong>{baht(grandTotal)} บาท</strong>
              </div>
              {cart.length > 0 && (
                <p className="o-warn">
                  ในตะกร้ายังมี {cart.length} รายการที่ยังไม่ได้ส่ง
                  ถ้าเรียกเก็บเงินตอนนี้จะไม่ถูกส่งเข้าครัว
                </p>
              )}
              {billError && (
                <p className="o-err" role="alert">
                  {billError}
                </p>
              )}
              <div className="o-modal-actions">
                <button
                  type="button"
                  ref={cancelRef}
                  onClick={() => setShowBill(false)}
                  disabled={closing}
                >
                  ยกเลิก
                </button>
                <button
                  type="button"
                  className="o-confirm"
                  onClick={handleConfirmBill}
                  disabled={closing}
                >
                  {closing ? 'กำลังดำเนินการ...' : 'ยืนยัน'}
                </button>
              </div>
            </div>
          </div>
        )}
      </>
    );
  }

  return (
    <div className="o-root">
      <style>{css}</style>
      {body}
    </div>
  );
}

const css = `
:where(.o-root) *{box-sizing:border-box}
:where(.o-root) button{font:inherit;cursor:pointer}
.o-root{
  --o-bg:#e3f4ec;--o-ink:#3a2220;--o-accent:#e5456b;--o-cream:#fff1b8;
  --o-paper:#fff;--o-muted:#6b4b47;
  min-height:100vh;min-height:100dvh;background:var(--o-bg);color:var(--o-ink);
}
.o-root button:disabled{cursor:not-allowed}
.o-root button:focus-visible{outline:3px solid var(--o-accent);outline-offset:2px}

.o-sticky{position:sticky;top:0;z-index:20;background:var(--o-bg);
  border-bottom:2px solid var(--o-ink);padding-top:env(safe-area-inset-top,0px)}
.o-inner{max-width:32rem;margin:0 auto}
.o-top{display:flex;align-items:center;justify-content:space-between;
  gap:.75rem;padding:.75rem 1rem .5rem}
.o-shop{display:block;font-size:1.35rem;font-weight:700;color:var(--o-accent);line-height:1.2}
.o-table{display:block;font-weight:500}
.o-bill-btn{min-height:2.75rem;padding:0 1rem;border-radius:999px;
  border:2px solid var(--o-ink);background:var(--o-paper);color:var(--o-ink);font-weight:500}
.o-tabs{display:flex;gap:.5rem;overflow-x:auto;padding:.25rem 1rem .75rem;
  scroll-snap-type:x proximity;scrollbar-width:none}
.o-tabs::-webkit-scrollbar{display:none}
.o-tab{flex:0 0 auto;scroll-snap-align:start;min-height:2.75rem;padding:0 1.1rem;
  border-radius:999px;border:2px solid var(--o-ink);background:var(--o-paper);
  color:var(--o-ink);font-weight:500;white-space:nowrap}
.o-tab[aria-selected="true"]{background:var(--o-accent);border-color:var(--o-accent);color:#fff}

.o-menu{max-width:32rem;margin:0 auto;padding:1rem 1rem 9rem}
.o-card{background:var(--o-paper);border:2px solid var(--o-ink);border-radius:1rem;overflow:hidden}
.o-card h2{font-size:1.25rem;color:var(--o-accent);padding:1rem 1rem .6rem}
.o-empty{padding:1rem;color:var(--o-muted)}
.o-list{list-style:none}
.o-item{display:flex;align-items:center;justify-content:space-between;gap:1rem;
  padding:.7rem 1rem;min-height:4rem;border-top:1px dashed var(--o-ink)}
.o-item.in-cart{background:var(--o-cream)}
.o-item-name{font-size:1.1rem;line-height:1.35}
.o-add{flex:0 0 auto;width:3rem;height:3rem;border-radius:50%;
  border:2px solid var(--o-ink);background:var(--o-cream);color:var(--o-ink);
  font-size:1.6rem;line-height:1}
.o-add:active:not(:disabled){background:var(--o-accent);border-color:var(--o-accent);color:#fff}
.o-add:disabled{opacity:.35}

.o-stepper{display:flex;align-items:center;gap:.25rem;flex:0 0 auto}
.o-stepper button{width:2.75rem;height:2.75rem;border-radius:50%;
  border:2px solid var(--o-ink);background:var(--o-paper);color:var(--o-ink);
  font-size:1.4rem;line-height:1}
.o-stepper button:last-child{background:var(--o-accent);border-color:var(--o-accent);color:#fff}
.o-stepper button:disabled{opacity:.35}
.o-stepper span{min-width:2rem;text-align:center;font-weight:700;font-size:1.1rem}

.o-cart{position:fixed;left:0;right:0;bottom:0;z-index:30;background:var(--o-bg);
  border-top:2px solid var(--o-ink);padding-bottom:env(safe-area-inset-bottom,0px)}
.o-cart-list{list-style:none;max-width:32rem;max-height:40vh;overflow-y:auto;
  margin:0 auto;padding:.25rem 1rem}
.o-cart-list li{display:flex;align-items:center;justify-content:space-between;
  gap:1rem;padding:.5rem 0;border-bottom:1px dashed var(--o-ink)}
.o-notice,.o-hint{max-width:32rem;margin:0 auto;padding:.6rem 1rem 0;font-weight:500}
.o-notice.ok{color:#1c6b47}
.o-notice.err{color:#b3163c}
.o-hint{color:var(--o-muted);font-size:.95rem;font-weight:400}
.o-cart-bar{max-width:32rem;margin:0 auto;padding:.75rem 1rem;display:flex;
  align-items:center;gap:.75rem}
.o-cart-toggle{flex:1;min-height:3.25rem;display:flex;align-items:center;
  justify-content:space-between;gap:.5rem;padding:0 1rem;border-radius:1rem;
  border:2px solid var(--o-ink);background:var(--o-paper);color:var(--o-ink);
  font-weight:500;text-align:left}
.o-cart-toggle:disabled{opacity:.6}
.o-send{flex:0 0 auto;min-height:3.25rem;padding:0 1.5rem;border-radius:1rem;
  border:2px solid var(--o-accent);background:var(--o-accent);color:#fff;
  font-weight:700;font-size:1.05rem}
.o-send:disabled{opacity:.45}

.o-backdrop{position:fixed;inset:0;z-index:50;background:rgba(58,34,32,.55);
  display:flex;align-items:flex-end;justify-content:center}
.o-modal{width:100%;max-width:32rem;background:var(--o-paper);
  border:2px solid var(--o-ink);border-bottom:0;border-radius:1.25rem 1.25rem 0 0;
  padding:1.25rem 1rem calc(1.25rem + env(safe-area-inset-bottom,0px));
  display:flex;flex-direction:column;gap:1rem}
@media (min-width:600px){
  .o-backdrop{align-items:center;padding:1rem}
  .o-modal{border-bottom:2px solid var(--o-ink);border-radius:1.25rem}
}
.o-modal h2{font-size:1.35rem}
.o-bill{list-style:none;display:flex;flex-direction:column;gap:.5rem}
.o-bill li{display:flex;justify-content:space-between;gap:1rem;
  padding-bottom:.5rem;border-bottom:1px dashed var(--o-ink)}
.o-total{display:flex;justify-content:space-between;align-items:baseline;
  gap:1rem;font-weight:700}
.o-total strong{font-size:1.9rem;color:var(--o-accent)}
.o-warn{background:var(--o-cream);border:2px solid var(--o-ink);
  border-radius:.75rem;padding:.6rem .8rem;font-weight:500}
.o-err{color:#b3163c;font-weight:500}
.o-modal-actions{display:flex;gap:.75rem}
.o-modal-actions button{flex:1;min-height:3.25rem;border-radius:1rem;
  border:2px solid var(--o-ink);background:var(--o-paper);color:var(--o-ink);font-weight:500}
.o-modal-actions .o-confirm{background:var(--o-accent);border-color:var(--o-accent);
  color:#fff;font-weight:700}
.o-modal-actions button:disabled{opacity:.5}

.o-full{min-height:100vh;min-height:100dvh;display:flex;flex-direction:column;
  align-items:center;justify-content:center;gap:1rem;text-align:center;padding:2rem 1.5rem}
.o-full h1{font-size:clamp(1.75rem,8vw,2.5rem);line-height:1.3;color:var(--o-accent)}
.o-full p{font-size:1.1rem}
`;
